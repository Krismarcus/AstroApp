using UIKit;

namespace Astrodaiva.Services
{
    public static class OrientationState
    {
        public static UIInterfaceOrientationMask SupportedMask { get; set; } =
            UIInterfaceOrientationMask.All;
    }
}
