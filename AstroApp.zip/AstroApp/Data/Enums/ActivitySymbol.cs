﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AstroApp.Data.Enums
{
    public enum ActivitySymbol
    {
        Barber,
        Beauty,
        BuyStuff,
        Contracts,
        ImportantTasks,
        Love,
        Meetings,
        NewIdeas,              
        Technologies,
        Travel,
    }
}
