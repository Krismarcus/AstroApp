using AstroApp.Data.Enums;
using AstroApp.Data.Models;
using System.ComponentModel;

namespace AstroApp.UI.Controls;

public partial class CalendarPlanetEventControl : ContentView
{
    public CalendarPlanetEventControl()
    {
        InitializeComponent();        
    }
}