﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Astrodaiva.Data.Enums
{
    public enum ActivityQuality
    {        
        Neutral,
        Good,
        Bad,
        None
    }
}
