﻿using Foundation;
using UIKit;

namespace Astrodaiva
{
    [Register("AppDelegate")]
    public class AppDelegate : MauiUIApplicationDelegate
    {
        protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();        
    }
}
